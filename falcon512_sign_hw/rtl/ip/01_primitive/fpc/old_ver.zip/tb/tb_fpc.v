`timescale 1ns/1ps

module tb_fpc;

//============================================================
// Parameters
//============================================================
parameter FLOAT_PRECISION = 64;

//============================================================
// Clock / Reset
//============================================================
reg clk;
reg rst_n;

initial begin
    clk = 1'b0;
end

always #5 clk = ~clk;

//============================================================
// Error counter
//============================================================
integer err;

//============================================================
// IEEE-754 double constants
//============================================================
localparam [63:0] FP_0    = 64'h0000000000000000;
localparam [63:0] FP_1    = 64'h3FF0000000000000;
localparam [63:0] FP_2    = 64'h4000000000000000;
localparam [63:0] FP_3    = 64'h4008000000000000;
localparam [63:0] FP_4    = 64'h4010000000000000;
localparam [63:0] FP_5    = 64'h4014000000000000;
localparam [63:0] FP_6    = 64'h4018000000000000;
localparam [63:0] FP_7    = 64'h401C000000000000;
localparam [63:0] FP_10   = 64'h4024000000000000;
localparam [63:0] FP_N5   = 64'hC014000000000000;

//============================================================
// FPC_ADD signals
//============================================================
reg  [63:0] add_a_re;
reg  [63:0] add_a_im;
reg  [63:0] add_b_re;
reg  [63:0] add_b_im;

wire [63:0] add_d_re;
wire [63:0] add_d_im;

//============================================================
// FPC_SUB signals
//============================================================
reg  [63:0] sub_a_re;
reg  [63:0] sub_a_im;
reg  [63:0] sub_b_re;
reg  [63:0] sub_b_im;

wire [63:0] sub_d_re;
wire [63:0] sub_d_im;

//============================================================
// FPC_MUL signals
//============================================================
reg         mul_in_valid;
reg  [63:0] mul_a_re;
reg  [63:0] mul_a_im;
reg  [63:0] mul_b_re;
reg  [63:0] mul_b_im;

wire        mul_valid;
wire [63:0] mul_d_re;
wire [63:0] mul_d_im;

//============================================================
// DUT instances
//============================================================
FPC_ADD #(
    .FLOAT_PRECISION(FLOAT_PRECISION)
) u_fpc_add (
    .a_re (add_a_re),
    .a_im (add_a_im),
    .b_re (add_b_re),
    .b_im (add_b_im),
    .d_re (add_d_re),
    .d_im (add_d_im)
);

FPC_SUB #(
    .FLOAT_PRECISION(FLOAT_PRECISION)
) u_fpc_sub (
    .a_re (sub_a_re),
    .a_im (sub_a_im),
    .b_re (sub_b_re),
    .b_im (sub_b_im),
    .d_re (sub_d_re),
    .d_im (sub_d_im)
);

FPC_MUL #(
    .FLOAT_PRECISION(FLOAT_PRECISION)
) u_fpc_mul (
    .clk        (clk),
    .rst_n      (rst_n),
    .in_valid   (mul_in_valid),
    .a_re       (mul_a_re),
    .a_im       (mul_a_im),
    .b_re       (mul_b_re),
    .b_im       (mul_b_im),
    .mult_valid (mul_valid),
    .d_re       (mul_d_re),
    .d_im       (mul_d_im)
);

//============================================================
// Check task
//============================================================
task check_hex64;
    input [511:0] name;
    input [63:0] got;
    input [63:0] exp;
    begin
        if (got !== exp) begin
            $display("[FAIL] %0s: got = %h, expected = %h", name, got, exp);
            err = err + 1;
        end
        else begin
            $display("[PASS] %0s: %h", name, got);
        end
    end
endtask

task check_bool;
    input [511:0] name;
    input got;
    input exp;
    begin
        if (got !== exp) begin
            $display("[FAIL] %0s: got = %0b, expected = %0b", name, got, exp);
            err = err + 1;
        end
        else begin
            $display("[PASS] %0s: %0b", name, got);
        end
    end
endtask

//============================================================
// Main test
//============================================================
initial begin
    err = 0;

    $dumpfile("build_fpc/tb_fpc.vcd");
    $dumpvars(0, tb_fpc);

    rst_n        = 1'b0;
    mul_in_valid = 1'b0;

    add_a_re = FP_0;
    add_a_im = FP_0;
    add_b_re = FP_0;
    add_b_im = FP_0;

    sub_a_re = FP_0;
    sub_a_im = FP_0;
    sub_b_re = FP_0;
    sub_b_im = FP_0;

    mul_a_re = FP_0;
    mul_a_im = FP_0;
    mul_b_re = FP_0;
    mul_b_im = FP_0;

    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    @(posedge clk);
    #1;

    //========================================================
    // Test FPC_ADD
    //========================================================
    $display("========================================");
    $display("TEST FPC_ADD");
    $display("========================================");

    // (1 + 2j) + (3 + 4j) = 4 + 6j
    add_a_re = FP_1;
    add_a_im = FP_2;
    add_b_re = FP_3;
    add_b_im = FP_4;
    #5;

    check_hex64("FPC_ADD real 1+3=4", add_d_re, FP_4);
    check_hex64("FPC_ADD imag 2+4=6", add_d_im, FP_6);

    //========================================================
    // Test FPC_SUB
    //========================================================
    $display("========================================");
    $display("TEST FPC_SUB");
    $display("========================================");

    // (5 + 7j) - (2 + 3j) = 3 + 4j
    sub_a_re = FP_5;
    sub_a_im = FP_7;
    sub_b_re = FP_2;
    sub_b_im = FP_3;
    #5;

    check_hex64("FPC_SUB real 5-2=3", sub_d_re, FP_3);
    check_hex64("FPC_SUB imag 7-3=4", sub_d_im, FP_4);

	//========================================================
	// Test FPC_MUL
	//========================================================
	$display("========================================");
	$display("TEST FPC_MUL");
	$display("========================================");

	// (1 + 2j) * (3 + 4j)
	// real = 1*3 - 2*4 = -5
	// imag = 1*4 + 2*3 = 10

	@(negedge clk);
	mul_a_re     = FP_1;
	mul_a_im     = FP_2;
	mul_b_re     = FP_3;
	mul_b_im     = FP_4;
	mul_in_valid = 1'b1;

	// Check result at the next posedge
	@(posedge clk);
	#1;

	check_bool ("FPC_MUL mult_valid", mul_valid, 1'b1);
	check_hex64("FPC_MUL real",       mul_d_re, FP_N5);
	check_hex64("FPC_MUL imag",       mul_d_im, FP_10);

	// Drop valid
	@(negedge clk);
	mul_in_valid = 1'b0;

	@(posedge clk);
	#1;

	check_bool("FPC_MUL valid drop", mul_valid, 1'b0);

    $display("========================================");

    if (err == 0) begin
        $display("FPC PRIMITIVE TEST PASS");
    end
    else begin
        $display("FPC PRIMITIVE TEST FAIL: %0d errors", err);
    end

    $display("========================================");

    $finish;
end

endmodule
