#!/bin/bash

mkdir -p build_fpc

vcs -debug +v2k -sverilog \
    -y /home/eda/synopsys/syn_vD-2010.03-SP4/dw/sim_ver +libext+.v \
    -f list_fpc.f \
    ../tb/tb_fpc.v \
    -l build_fpc/compile_fpc.log \
    -o build_fpc/simv_fpc

./build_fpc/simv_fpc \
    -l build_fpc/run_fpc.log
